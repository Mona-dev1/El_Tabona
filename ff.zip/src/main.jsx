import React from 'react'; // 👈 ضروري لاستخدام React.StrictMode
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
// 💡 تأكدي من المسار: إذا كان مجلدك src/context، فالمسار هو './context/ThemeContext.jsx'
import { ThemeProvider } from "./assets/context/themecontext.jsx";
// 1. تحديد العنصر الجذري (root element)
const container = document.getElementById('root');
const root = createRoot(container); // إنشاء الـ root

// 2. ربط التطبيق بالـ DOM (مرة واحدة فقط)
root.render(
  // استخدام React.StrictMode إذا أردتِ
  <React.StrictMode> 
    {/* وضع الـ ThemeProvider هنا لتغليف التطبيق بالكامل */}
    <ThemeProvider>
      <App />
    </ThemeProvider>
  </React.StrictMode>
);